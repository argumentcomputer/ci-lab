gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,8367529548524-24-02-21
