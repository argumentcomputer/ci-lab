gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,8e60c670a1320-24-02-20
